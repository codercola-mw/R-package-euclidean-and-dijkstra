library(testthat)
library(luckpack)

test_check("luckpack")
